module.exports = {
    plugins: [require('autoprefixer')]
};
// 7.2.6